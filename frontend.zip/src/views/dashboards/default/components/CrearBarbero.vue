<script setup lang="ts">
import { ref } from 'vue'
import { useBarberStore } from '@/stores/barber'

const barberStore = useBarberStore()

const form = ref({
  nombre: '',
  apellido: '',
  email: '',
  password: '',
  telefono: '',
  foto: '', // si tienes foto
})

const submit = async () => {
  try {
    await barberStore.createBarber(form.value)
    alert('Barbero creado!')
  } catch (error) {
    console.error(error)
  }
}
</script>

<template>
  <form @submit.prevent="submit">
    <input v-model="form.nombre" placeholder="Nombre"/>
    <input v-model="form.apellido" placeholder="Apellido"/>
    <input v-model="form.email" placeholder="Email"/>
    <input v-model="form.password" type="password" placeholder="Password"/>
    <input v-model="form.telefono" placeholder="Teléfono"/>
    <button type="submit">Crear Barbero</button>
  </form>
</template>
